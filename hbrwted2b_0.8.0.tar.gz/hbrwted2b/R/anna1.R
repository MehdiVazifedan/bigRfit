anna1 <- function(p,alpha=0.05){

	betahbr <- matrix(scan("hbrwts.out"),ncol=p,byrow=T)
	betahbrse <- matrix(scan("hbrwtsse.out"),ncol=p,byrow=T)
	betawil <- matrix(scan("wilc.out"),ncol=p,byrow=T)
	betawilse <- matrix(scan("wilcse.out"),ncol=p,byrow=T)
	oldhbr <- matrix(scan("oldhbr.out"),ncol=p,byrow=T)
	oldhbrse <- matrix(scan("oldhbrse.out"),ncol=p,byrow=T)
	lshold <- matrix(scan("lshold.out"),ncol=p,byrow=T)
	lsholdse <- matrix(scan("lsholdse.out"),ncol=p,byrow=T)


	n <- length(betahbr[,1])
	df <- n - (p+1)
	tc <- abs(qt(alpha/2,df))

	confhbr <- c()
	confwil <- c()
	confoldhbr <- c()
	confoldwted <- c()
	confls <- c()

        msels <- c(); msehbr <- c(); msewil <- c(); mseoldhbr <- c(); mseoldhbrwted <- c()
	for(j in 1:p){
		vec <- betahbr[,j]; vecse <- betahbrse[,j]
		confhbr <- c(confhbr,cter(vec,vecse,tc))
		vec <- betawil[,j]; vecse <- betawilse[,j]
		confwil <- c(confwil,cter(vec,vecse,tc))
		vec <- oldhbr[,j]; vecse <- oldhbrse[,j]
		confoldhbr <- c(confoldhbr,cter(vec,vecse,tc))
		vec <- betahbr[,j]; vecse  <- oldhbrse[,j]
		confoldwted <- c(confoldwted,cter(vec,vecse,tc))
		vec <- lshold[,j]; vecse  <- lsholdse[,j]
		confls <- c(confls,cter(vec,vecse,tc))
	}
	tab <- rbind(confhbr,confwil,confoldhbr,confoldwted,confls)
	colnames(tab) <- 1:p
	rownames(tab) <- c("HBR WTED w Rfit tau","WIL","HBR","HBRWTED SEHBR","LS")

	for(j in 1:p){
                vec <- lshold[,j]
		tmpls <- mses(vec)
                msels <- c(msels,tmpls)

                vec <- betahbr[,j]
		tmp <- tmpls/mses(vec)
                msehbr <- c(msehbr,tmp)

                vec <- betawil[,j]
		tmp <- tmpls/mses(vec)
		msewil <- c(msewil,tmp)

                vec <- oldhbr[,j]
		tmp <- tmpls/mses(vec)
		mseoldhbr <- c(mseoldhbr,tmp)

                vec <- betahbr[,j]
		tmp <- tmpls/mses(vec)
		mseoldhbrwted <- c(mseoldhbrwted,tmp)

        }
        tab2 <- rbind(msehbr,msewil, mseoldhbr,mseoldhbrwted)
        colnames(tab2) <- 1:p
        rownames(tab2) <- c("HBR WTED w Rfit tau","WIL","HBR","HBRWTED SEHBR")

	list(TableEmpConf=tab,TableAREs=tab2)
}

mses <- function(vec,theta=0){
	n <- length(vec)
	mses <- sum((vec - theta)^2)/n
	return(mses)
}

cter <- function(vec,vecse,tc){

	lb <- vec - tc*vecse; ub <- vec + tc*vecse; n<- length(vec)
	ind <- 0
	for(i in 1:n){
		if(lb[i]*ub[i] < 0){ind <- ind + 1}
	}
	lev <- ind/n
	return(lev)
}
