rcn = function(n,eps,mu,sigma){
     ind = rbinom(n,1,eps)
     z = rnorm(n)
     rcn = (1-ind)*z + ind*(sigma*z)+mu
     rcn
}
