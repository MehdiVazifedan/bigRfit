disp <- function( ehat, scores ) {
  sum( ehat*scores )
}
