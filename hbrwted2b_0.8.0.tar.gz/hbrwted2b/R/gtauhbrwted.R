gtauhbrwted <- function(fit,B,scores){
	ehat <- fit$resid
        breaks <- get_breaks(ehat,B)
	scrs <- getScores.brf(ehat,breaks,scores)
        tauhat <- tauhat.gs(scrs$mids,scrs$counts,scores,bw.nrd(ehat))
        return(tauhat)
}
