driver <- function(xmat,y,numstp=10,epcchk=0.0001,B=101,scores=wscores){

     fit <- hbrwfit2(xmat,y,numstp,epcchk,B,scores)

### vcov just beta

     x <- centerx(xmat)

      
###      list(coef=coef,fitted.values=fitted.values,residuals=residuals,kp1fit=kp1fit,matbeta=matbeta,finwts=finwts,robdis2=robdis2,ehatlts=ehatlts)

     ##  this is the tauhat we want
##        tauhat <- gtauhbrwted(fit,B,scores)
        tauhat <- gettauF0(fit$resid)

        wts2 <- fit$finwts[,1]
        x2 <- x*sqrt(wts2)
	qx2 <- qr(x2)
	rmat <- qr.R(qx2)
	ri <- qr.solve(rmat)
	vc <- tauhat*ri%*%t(ri)

	se <- sqrt(diag(vc))

	qx <- qr(x); beta <- fit$coef[-1]
	y2<-qr.Q(qx)%*%qr.R(qx)%*%beta
	resid2 <- y - y2
	alp <- median(resid2)
	pp1 <- length(x[1,])+1
	sealp <- taustar(resid2,pp1)/sqrt(length(y))
	yhat <- y - resid2 + alp
	coef <- c(alp,beta)
	se <- c(sealp,se)

        list(coef=coef,se=se,fitted.values=yhat,residuals=resid2,tauhat=tauhat,vc=vc,se=se,fit=fit)
}
#	ehat <- fit$resid
#        breaks <- get_breaks(ehat,B)
#	scrs <- getScores.brf(ehat,breaks,scores)
#        tauhat <- tauhat.gs(scrs$mids,scrs$counts,scores,bw.nrd(ehat))
#        return(tauhat)




