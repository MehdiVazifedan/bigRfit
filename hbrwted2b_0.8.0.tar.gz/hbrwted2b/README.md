# rewtedhbr
R package for reweighed HBR fits  
This is the version of July 2018.   
