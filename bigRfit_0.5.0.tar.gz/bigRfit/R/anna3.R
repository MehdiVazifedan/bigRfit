anna3 <- function(p=5){

mat1 <- matrix(scan("big1.out"),ncol=(p+1),byrow=T)
mat2 <- matrix(scan("big2.out"),ncol=(p+1),byrow=T)
mat3 <- matrix(scan("big3.out"),ncol=(p+1),byrow=T)

     vec1 <- mser(mat1)
     vec2 <- mser(mat2)
     vec3 <- mser(mat3)
     are12 <- vec1/vec2
     are13 <- vec1/vec3
     ares <- rbind(are12,are13)
     colnames(ares) <- 1:(p+1)
     rownames(ares) <- c("est1/est2","est1/est3")
     #val <- c()
     #valls <- c()
#
     #for(j in 1:p){
        #est1 <- mat1[,j]
        #se1 <- mat1se[,j]
        #val <- c(val,validci(est1,se1))
        #est2 <- mat2[,j]
        #se2 <- mat2se[,j]
        #valls <- c(valls,validci(est2,se2))
     #}
     return(ares)
}

validci <- function(est,se,alp=.05){

     zc <- qnorm(1-(alp/2))
     n <- length(est)
     ind <- 0

     for(i in 1:n){
         lb <- est[i] - zc*se[i]
         ub <- est[i] + zc*se[i]
         if(lb*ub < 0){ind <- ind + 1}
     }
     ind <- ind/n
     return(ind)
}

mser <- function(mat){

      n <- length(mat[,1])
      p <- length(mat[1,])
      coll <- c()

      for(j in 1:p){
         vec <- sum(mat[,j]^2)/n
         coll <- c(coll,vec)
      }
      return(coll)
}
