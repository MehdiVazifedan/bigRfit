dftauhat <- function(tauhat,ehat,param,p){

	epshc <- 0.000001
	n <- length(ehat)
	ind <- rep(0,n)
	ind[abs(ehat/tauhat) < param] <- 1
	hubcor <- sum(ind)/n
	if(hubcor < epshc){hubcor <- epshc}
	corr <- sqrt(n/(n-p))*(1 + ((p/n)*((1-hubcor)/hubcor)))
	tauhat <- tauhat*corr
	return(tauhat)
}
