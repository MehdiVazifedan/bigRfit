skewns = new("scores",phi=function (u,param)
{   alp = param[1]
    f3 = qsn(u,alpha=alp)
    top = f3 - ((alp*dnorm(alp*f3))/pnorm(alp*f3))
    top
}
,Dphi=function (u,param)
{
    alp = param[1]
    f3 = qsn(u,alpha=alp)
    part1 = alp*f3*pnorm(alp*f3) + dnorm(alp*f3)
    part2 = (alp^2*dnorm(alp*f3)*part1)/(pnorm(alp*f3)^2)
    part3 = (1 + part2)/(2*dnorm(f3)*pnorm(alp*f3))
    part3
},param=c(1))


