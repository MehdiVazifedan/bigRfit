anna2 <- function(p=21){

     mat1 <- matrix(scan("big.out"),ncol=p,byrow=T)
     mat2 <- matrix(scan("r.out"),ncol=p,byrow=T)
#     mat1se <- matrix(scan("bigse.out"),ncol=p,byrow=T)
#     mat2se <- matrix(scan("lsse.out"),ncol=p,byrow=T)

     vecr <- mser(mat1)
     vecls <- mser(mat2)
     ares <- vecls/vecr

     #val <- c()
     #valls <- c()
#
     #for(j in 1:p){
        #est1 <- mat1[,j]
        #se1 <- mat1se[,j]
        #val <- c(val,validci(est1,se1))
        #est2 <- mat2[,j]
        #se2 <- mat2se[,j]
        #valls <- c(valls,validci(est2,se2))
     #}
     list(ares=ares)
}

validci <- function(est,se,alp=.05){

     zc <- qnorm(1-(alp/2))
     n <- length(est)
     ind <- 0

     for(i in 1:n){
         lb <- est[i] - zc*se[i]
         ub <- est[i] + zc*se[i]
         if(lb*ub < 0){ind <- ind + 1}
     }
     ind <- ind/n
     return(ind)
}

mser <- function(mat){

      n <- length(mat[,1])
      p <- length(mat[1,])
      coll <- c()

      for(j in 1:p){
         vec <- sum(mat[,j]^2)/n
         coll <- c(coll,vec)
      }
      return(coll)
}
